let bird;
let obstacles = [];
let estado = 'inicio';
let pontuacao = 0;

function setup() {
  createCanvas(400, 400);
  frameRate(60);
  iniciarJogo();
}

function iniciarJogo() {
  bird = new Bird(width / 3, height / 3);
  obstacles = [];
  pontuacao = 0;
  estado = 'inicio';
}

function startGame() {
  bird = new Bird(width / 3, height / 3);
  obstacles = [];
  pontuacao = 0;
  estado = 'jogando';
}

function draw() {
  background("lightblue");
  desenharCenario();

  if (estado === 'inicio') {
    mostrarTelaInicio();
  } else if (estado === 'jogando') {
    jogar();
  } else if (estado === 'fim') {
    mostrarTelaFim();
  }
}

function desenharCenario() {
  noStroke();
  fill(91, 71, 110);
  triangle(360, 130, 760, 500, -40, 500);
  fill(213, 212, 255);
  beginShape();
  vertex(360, 130);
  vertex(485, 246);
  vertex(390, 200);
  vertex(360, 250);
  vertex(320, 217);
  vertex(225, 255);
  endShape(CLOSE);
  fill(174, 139, 222);
  triangle(100, 180, 500, 500, -260, 500);
  fill(231, 241, 255);
  beginShape();
  vertex(100, 180);
  vertex(225, 280);
  vertex(145, 250);
  vertex(120, 290);
  vertex(70, 260);
  vertex(-20, 286);
  endShape(CLOSE);
}

function jogar() {
  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].update();
    obstacles[i].show();

    if (obstacles[i].hits(bird)) {
      estado = 'fim';
      return;
    }

    if (!obstacles[i].marcouPonto && obstacles[i].x + obstacles[i].w < bird.x) {
      pontuacao++;
      obstacles[i].marcouPonto = true;
    }

    if (obstacles[i].offscreen()) {
      obstacles.splice(i, 1);
    }
  }

  if (frameCount % 90 === 0) {
    obstacles.push(new Obstacle());
  }

  bird.update();
  bird.show();

  // Perde se tocar nas bordas superior ou inferior
  if (bird.y <= 0 || bird.y >= height) {
    estado = 'fim';
    return;
  }

  fill(0);
  textSize(24);
  textAlign(LEFT, TOP);
  text("Pontos: " + pontuacao, 10, 10);
}

function mostrarTelaInicio() {
  fill(0);
  textAlign(CENTER, CENTER);
  textSize(24);
  text("🌎 Jogo de desviar do lixo
       ", width / 2, height / 2 - 40);
  textSize(16);
  text("Clique ou pressione ESPAÇO para começar", width / 2, height / 2);
}

function mostrarTelaFim() {
  fill(0);
  textAlign(CENTER, CENTER);
  textSize(24);
  text("💥 Você bateu!", width / 2, height / 2 - 40);
  textSize(16);
  text("Pontos finais: " + pontuacao, width / 2, height / 2);
  text("Clique ou pressione ESPAÇO para reiniciar", width / 2, height / 2 + 30);
}

class Bird {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocity = 0;
    this.gravity = 0.6;
    this.lift = -10;
    this.size = 32;
  }

  flap() {
    this.velocity = this.lift;
  }

  update() {
    this.velocity += this.gravity;
    this.y += this.velocity;
    this.y = constrain(this.y, 0, height);
  }

  show() {
    push();
    translate(this.x, this.y);
    rotate(this.velocity / 10);
    // Corpo
    fill(255, 255, 0);
    ellipse(0, 0, this.size, this.size * 0.7);
    // Asa
    fill(255, 200, 0);
    ellipse(-8, 0, this.size / 2, this.size / 3);
    // Olho
    fill(0);
    ellipse(6, -5, 6, 6);
    pop();
  }
}

class Obstacle {
  constructor() {
    this.x = width;
    this.y = random(100, height - 100);
    this.w = 30;
    this.h = 40;
    this.speed = 2;
    this.tipo = random(['garrafa', 'sacola', 'lata']);
    this.marcouPonto = false;
  }

  update() {
    this.x -= this.speed;
  }

  show() {
    if (this.tipo === 'garrafa') {
      // Garrafa: corpo com gradiente e brilho
      push();
      translate(this.x, this.y);
      noStroke();
      // Sombra da garrafa
      fill(30, 80, 160, 150);
      ellipse(this.w / 2, this.h, this.w * 0.9, this.h * 0.6);

      // Corpo da garrafa
      fill(0, 120, 220);
      rect(0, 0, this.w, this.h, 8);

      // Reflexo na garrafa
      fill(255, 255, 255, 120);
      beginShape();
      vertex(this.w * 0.3, 5);
      vertex(this.w * 0.45, 5);
      vertex(this.w * 0.4, this.h - 5);
      vertex(this.w * 0.25, this.h - 5);
      endShape(CLOSE);

      // Gargalo
      fill(20, 60, 110);
      rect(this.w * 0.35, -10, this.w * 0.3, 10, 5);
      pop();
    } 
    else if (this.tipo === 'sacola') {
      // Sacola: forma leve com alças e sombra
      push();
      translate(this.x, this.y);
      noStroke();

      // Sombra
      fill(180, 180, 180, 140);
      ellipse(this.w / 2, this.h + 5, this.w * 1.1, this.h * 0.5);

      // Corpo
      fill(240);
      rect(0, 0, this.w, this.h, 15);

      // Dobras da sacola
      stroke(200);
      strokeWeight(2);
      line(this.w * 0.3, this.h * 0.3, this.w * 0.3, this.h);
      line(this.w * 0.7, this.h * 0.3, this.w * 0.7, this.h);

      // Alças
      noFill();
      stroke(180);
      strokeWeight(3);
      arc(this.w * 0.25, 0, 12, 15, PI, TWO_PI);
      arc(this.w * 0.75, 0, 12, 15, PI, TWO_PI);

      pop();
    } 
    else if (this.tipo === 'lata') {
      // Lata: elipse 3D com sombras e detalhes
      push();
      translate(this.x, this.y);
      noStroke();

      // Sombra embaixo
      fill(120, 120, 120, 150);
      ellipse(this.w / 2, this.h, this.w * 1.1, this.h * 0.6);

      // Corpo da lata
      fill(180);
      ellipse(this.w / 2, this.h / 2, this.w, this.h);

      // Brilho frontal
      fill(220);
      ellipse(this.w / 2 + 3, this.h / 2 - 10, this.w / 3, this.h / 4);

      // Tampa superior
      fill(160);
      ellipse(this.w / 2, this.h / 4, this.w * 0.7, this.h / 6);

      // Detalhes verticais (costelas da lata)
      stroke(140);
      strokeWeight(1);
      for(let i=5; i<this.w; i+=7){
        line(i, 0, i, this.h);
      }
      noStroke();

      pop();
    }
  }

  offscreen() {
    return this.x + this.w < 0;
  }

  hits(bird) {
    let r = bird.size / 2;

    let rx = this.x;
    let ry = this.y;
    let rw = this.w;
    let rh = this.h;

    let closestX = constrain(bird.x, rx, rx + rw);
    let closestY = constrain(bird.y, ry, ry + rh);

    let distX = bird.x - closestX;
    let distY = bird.y - closestY;
    let distance = sqrt(distX * distX + distY * distY);

    return distance < r;
  }
}

function mousePressed() {
  if (estado !== 'jogando') startGame();
  else bird.flap();
}

function keyPressed() {
  if (key === ' ') {
    if (estado !== 'jogando') startGame();
    else bird.flap();
  }
}
